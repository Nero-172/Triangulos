package triangulos;

public class Banda {
    private Punto inicio;
    private Punto fin;
    private boolean esBlanco; // true si fue colocada por el jugador blanco
    
    public Banda(Punto inicio, Punto fin, boolean esBlanco) {
        this.inicio = inicio;
        this.fin = fin;
        this.esBlanco = esBlanco;
    }
    
    public Punto getInicio() {
        return inicio;
    }
    
    public Punto getFin() {
        return fin;
    }
    
    public boolean esBlanco() {
        return esBlanco;
    }
    
    // Método mejorado para detectar si un punto está en la banda
    public boolean pasaPorPunto(Punto punto) {
        // Verificar si el punto está en los extremos
        if (inicio.equals(punto) || fin.equals(punto)) {
            return true;
        }
        
        // Obtener las diferencias
        int deltaCol = fin.getColumna() - inicio.getColumna();
        int deltaFila = fin.getFila() - inicio.getFila();
        
        // Para bandas horizontales (Este-Oeste)
        if (deltaFila == 0) {
            if (punto.getFila() == inicio.getFila()) {
                char colMin = (char) Math.min(inicio.getColumna(), fin.getColumna());
                char colMax = (char) Math.max(inicio.getColumna(), fin.getColumna());
                
                // Verificar si el punto está entre los extremos de la banda horizontal
                return punto.getColumna() >= colMin && punto.getColumna() <= colMax;
            }
            return false;
        }
        
        // Para bandas verticales (Norte-Sur)
        if (deltaCol == 0) {
            if (punto.getColumna() == inicio.getColumna()) {
                int filaMin = Math.min(inicio.getFila(), fin.getFila());
                int filaMax = Math.max(inicio.getFila(), fin.getFila());
                return punto.getFila() >= filaMin && punto.getFila() <= filaMax;
            }
            return false;
        }
        
        // Para bandas diagonales
        // Verificar si el punto está en la línea que conecta inicio y fin
        
        // Primero, verificar si el punto está dentro del rectángulo formado por inicio y fin
        char colMin = (char) Math.min(inicio.getColumna(), fin.getColumna());
        char colMax = (char) Math.max(inicio.getColumna(), fin.getColumna());
        int filaMin = Math.min(inicio.getFila(), fin.getFila());
        int filaMax = Math.max(inicio.getFila(), fin.getFila());
        
        if (punto.getColumna() < colMin || punto.getColumna() > colMax || 
            punto.getFila() < filaMin || punto.getFila() > filaMax) {
            return false;
        }
        
        // Para diagonales, verificar si el punto está en la línea
        // Usando la ecuación de la recta: (y - y1) / (x - x1) = (y2 - y1) / (x2 - x1)
        // Simplificando: (y - y1) * (x2 - x1) = (y2 - y1) * (x - x1)
        
        int x = punto.getColumna();
        int y = punto.getFila();
        int x1 = inicio.getColumna();
        int y1 = inicio.getFila();
        int x2 = fin.getColumna();
        int y2 = fin.getFila();
        
        // Verificar si el punto está en la línea
        return (y - y1) * (x2 - x1) == (y2 - y1) * (x - x1);
    }
    
    @Override
    public String toString() {
        return "Banda de " + inicio + " a " + fin;
    }

    boolean esBlanca() {
        return esBlanco;
    }
}
